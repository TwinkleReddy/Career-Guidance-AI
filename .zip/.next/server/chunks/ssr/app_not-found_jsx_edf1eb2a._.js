module.exports = {

"[project]/app/not-found.jsx [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),

};

//# sourceMappingURL=app_not-found_jsx_edf1eb2a._.js.map